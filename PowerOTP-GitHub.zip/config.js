
module.exports = {
  adminUser: "admin",
  adminPass: "power123"
};
